using UnityEngine;

namespace RoR2
{
	public class RagdollController : MonoBehaviour
	{
		public Transform[] bones;
		public MonoBehaviour[] componentsToDisableOnRagdoll;
	}
}
